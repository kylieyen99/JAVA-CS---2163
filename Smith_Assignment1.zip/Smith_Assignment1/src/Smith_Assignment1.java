/**
 * Author:		Kylie Smith
 * Date:		03/25/22
 * File:		Smith_Assignment.java
 * Description:	building a program to help new investors select a stock based on certain criteria
 */

import java.util.Scanner;
public class Smith_Assignment1 {
	public static void main(String[] args) {
		//create scanner
				Scanner input = new Scanner(System.in);
				
				double investmentMoney = 0;
				double stockPrice = 0;
				double amountOfStock = 0;
				double priceToEarnings = 0;
				String stockTicker;
				
				//greeting 
				System.out.print("Welcome to the Stock Picker App! " + "\n");
				
				//prompt user for money available to invest
				System.out.print("\n" + "Enter the total amount of money you are willing to invest: ");
				investmentMoney = input.nextDouble();
				 
				 //prompt user for stock ticker 
				 System.out.println("Enter the stock ticker: ");
				 stockTicker = input.next() + input.nextLine(); 
				 int maxLength = 5;
				 while (stockTicker.length() > maxLength){
					 System.out.println("Invalid input. Try again.");
					 stockTicker = input.next() + input.nextLine(); 
				 }
				 
				 //prompt user for stock price
				 System.out.print("Enter the stock price: ");
				 stockPrice = input.nextDouble();
				 
				 //check if stock price is at least $0.01
				 while (stockPrice < 0.01) {
					 System.out.println("Invalid input. Try again.");
					 stockPrice = input.nextDouble();
				 }
				 
				 //prompt user for P/E ratio
				 System.out.print("Enter the P/E Ratio: ");
				 priceToEarnings = input.nextDouble();
				 
				 //calculate amount of stock
				 amountOfStock = investmentMoney / stockPrice;
				 
				 //display results
				 System.out.println("\n" + "Below are your results: " + "\n");
				 System.out.println("Stock: " + stockTicker);
				 System.out.println("Price: " + stockPrice);
				 System.out.println("P/E Ratio: " + priceToEarnings);
				 if (priceToEarnings > 60) {
					 System.out.println("WARNING: This company may be overvalued!");
				 }
				 System.out.println("# of shares able to purchase: " + amountOfStock);

				 input.close();
	}

}
