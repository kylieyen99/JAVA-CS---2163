/**
 * Author:		Kylie Smith
 * Date:		04/01/22
 * File:		Smith_Assignment2.java
 * Description:	write a program that does book inventory each day
 */

import java.util.Scanner;
public class Smith_Assignment2 {
	public static void main(String[] args) {
		//create scanner
		Scanner input = new Scanner(System.in);
	
		int R = 0, C = 0, P = 0;
		char continueLoop = 'Y';
		
		System.out.println("Welcome to the Daily Book Inventory Program! ");
		
		while (continueLoop == 'Y') {  
		
		//prompt user for ISBN number
			System.out.print("\n" + "Please enter the 12 digits of an ISBN-13 as a String: ");
			String isbn = input.nextLine();
			int sum = 0;
			
		//check ISBN
			while (isbn.length() != 12) {
				System.out.print("Invalid ISBN-13 number. ");
				System.out.print("\n" + "Please enter the 12 digits of an ISBN-13 as a String: ");
				isbn = input.nextLine();
			}
			
		//calculate sum
			for (int i = 0; i < isbn.length(); i++) { 
				if ((i + 1) % 2 == 0) 
				    sum += isbn.charAt(i) - 48;
				else 
				    sum += 3 * (isbn.charAt(i) - 48);
				}
			int checkSum =  (10 - sum%10)%10;
			if (checkSum == 10)
				checkSum = 0;
			
		// display full ISBN number
			System.out.println("The ISBN-13 number is: " + isbn + checkSum);
			
		//prompt user for return or check-out
			System.out.print("\r\n" + "Enter 'R' for return or 'C' for check out: ");
			char rc = input.next().charAt(0);
			rc = Character.toUpperCase(rc);
			
			while (rc != 'R' && rc != 'C') {
				System.out.print("ERROR: Please enter 'R' for return or 'C' for check out: ");
				rc = input.next().charAt(0);
				rc = Character.toUpperCase(rc);
			}
			
		//count book inventory
			if (rc == 'R') {
				R++;
				P++;
			}
			else if (rc == 'C') {
				C++;
				P++;
			}
			
			
		//display book inventory
			System.out.println("\r\n" + "DAILY BOOK INVENTORY");
			System.out.println("Number of books returned: " + R);
			System.out.println("Number of books checked out: " + C);
			System.out.println("Total books processed: " + P);
			
		//prompt user for confirmation to continue
			System.out.print("Enter Y to continue and N to quit: ");
			continueLoop = input.next().charAt(0); //getLine instead of nextLine in book??
			continueLoop = Character.toUpperCase(continueLoop);
			
			while (continueLoop != 'Y' && continueLoop != 'N') { 
				System.out.print("ERROR: Please enter 'Y' to continue or 'N' to quit: ");
				continueLoop = input.next().charAt(0);
				continueLoop = Character.toUpperCase(continueLoop);
			}
			
		//final book inventory display
			if (continueLoop == 'N') {
				System.out.println("\r\n" + "DAILY BOOK INVENTORY");
				System.out.println("Number of books returned: " + R);
				System.out.println("Number of books checked out: " + C);
				System.out.println("Total books processed: " + P);
			}
			
			input.close();
			
		} //end bracket for continueLoop == 'Y'
		
		System.exit(0);
		
	} // end bracket for main
}// end bracket for class