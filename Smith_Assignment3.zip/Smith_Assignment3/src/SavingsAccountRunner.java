/**
 * Author:		Kylie Smith
 * Date:		04/15/22
 * File:		SavingsAccountRunner.java
 * Description:	create a small program used on an ATM for MidFirst Bank
 */

import java.util.Scanner;
public class SavingsAccountRunner {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
        SavingsAccount account = new SavingsAccount();
        System.out.println("Welcome to your Savings Account App! ");
        
        //prompt user for account number
        System.out.print("Enter your account number: ");
        account.setId(input.nextInt());
        
        //prompt user for initial balance
        System.out.print("Enter your initial balance: ");
        account.setBalance(input.nextDouble());
        
        //prompt user for annual interest rate
        System.out.print("Enter your annual interest rate: ");
        account.setAnnualIntRate(input.nextDouble());
        
        int choice = 0;
        do {
        
	        //prompt user for next course of action
	        System.out.println("\n===========================================");
	        System.out.println("=              OPTIONS BELOW              =");
	        System.out.println("===========================================\n");
	        System.out.println("1. Deposit");
	        System.out.println("2. View Weekly Interest Rate");
	        System.out.println("3. View Account Details");
	        System.out.println("4. Exit");
	        System.out.print("Enter your selection: ");
	        choice = input.nextInt();
	        
	        //check if choice is valid
	        while (choice < 1 || choice > 4) {
	        	System.out.println("INVALID SELECTION - TRY AGAIN.");
	        	System.out.print("Enter your selection: ");
	        	choice = input.nextInt();
	        }
	        
	        if (choice == 1) {
	        	System.out.print("Enter your deposit amount: ");
	        	double depositAmount = input.nextDouble();
	        	
	        	//check deposit amount
	        	while (depositAmount < 0) {
	        		System.out.println("ERROR. Deposit amount must be 0 or greater.");
	        		System.out.print("Enter your deposit amount: ");
	            	depositAmount = input.nextDouble();
	        	}
	            account.deposit(depositAmount); 
	        }
	        
	        else if (choice == 2) {
	        	System.out.println("Your Weekly Interest Amount is $ " + 
	        Math.round(account.getWeeklyIntRate() * 100.0) / 100.0);
	        }
	        
	        else if (choice == 3) {
	        	account.getAccountDetails();
	        }
	        
	        else {
	        System.out.println("Thank you - Goodbye !");
	        break;
	        }
        
        } while (choice != 4);
        
        
		input.close();
		
		System.exit(0);

        	
	} //main bracket 
} //class bracket
