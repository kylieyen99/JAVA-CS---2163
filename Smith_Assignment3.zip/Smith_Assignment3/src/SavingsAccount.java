/**
 * Author:		Kylie Smith
 * Date:		04/15/22
 * File:		SavingsAccount.java
 * Description:	creating a small program used on an ATM for MidFirst Bank
 */

import java.util.*;
public class SavingsAccount {	
	private int id;
	private double balance, annualIntRate;
	Date dateEstablished;	// should the date be private???
	
	//constructor
	public SavingsAccount() {
		 id = 0;
	     balance = 0;
	     annualIntRate = 0.0;
	     dateEstablished = new Date();
	}

	//getters
	public int getId() {
		return id;
	}

	public double getBalance() {
		return balance;
	}

	public double getAnnualIntRate() {
		return annualIntRate;
	}
	
	 public Date getDate(){
	        return this.dateEstablished;
	    }
	 
	//return the weekly interest rate for option 2
	 public double getWeeklyIntRate(){
	        double weeklyIntRate = (this.annualIntRate / 100) / 52;
	        return this.balance * weeklyIntRate;
	    }

	//setters
	public void setId(int id) {
		this.id = id;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public void setAnnualIntRate(double annualIntRate) {
		this.annualIntRate = annualIntRate;
	}
	

	//deposit a specified amount to the account and display the new balance for option 1
	public void deposit(double depositAmount){
        this.balance += depositAmount;
        System.out.println("New Balance: $ " + this.getBalance());
    }
	
	//gather account details for option 3
	public void getAccountDetails(){
        System.out.println();
        System.out.println("Account ID: " + this.getId());
        System.out.println("Account Creation Date/Time: "  +  this.getDate());
        System.out.println("Balance: " + this.getBalance());
        System.out.println("Weekly Interest Amount: $ " + Math.round(this.getWeeklyIntRate() * 100.0) / 100.0);
        System.out.println();
    }


}
	
	
	
